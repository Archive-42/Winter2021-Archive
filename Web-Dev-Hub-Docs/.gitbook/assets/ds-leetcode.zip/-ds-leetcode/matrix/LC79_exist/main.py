class Solution:
    def exist(self, board, word):

class MinStack:

    def __init__(self):

    def push(self, x):

    def pop(self):

    def top(self):

    def getMin(self):

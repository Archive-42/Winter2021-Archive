class MyQueue:
    def __init__(self):
        """
        Initialize your data structure here.
        """

    def push(self, x):
        """
        Push element x to the back of queue.
        """

    def pop(self):
        """
        Removes the element from in front of queue and returns that element.
        """

    def peek(self):
        """
        Get the front element.
        """

    def empty(self):
        """
        Returns whether the queue is empty.
        """

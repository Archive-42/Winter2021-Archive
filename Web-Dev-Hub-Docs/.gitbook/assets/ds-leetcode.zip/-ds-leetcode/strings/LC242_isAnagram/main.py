class Solution:
    def isAnagram(self, s, t):

class Solution:
    def eraseOverlapIntervals(self, intervals):

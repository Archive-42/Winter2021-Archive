class Solution:
    def findMin(self, nums):

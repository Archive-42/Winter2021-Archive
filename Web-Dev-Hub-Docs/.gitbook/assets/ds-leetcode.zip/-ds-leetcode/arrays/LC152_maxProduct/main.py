class Solution:
    def maxProduct(self, nums):

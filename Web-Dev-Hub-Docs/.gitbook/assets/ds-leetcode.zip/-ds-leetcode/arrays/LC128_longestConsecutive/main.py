class Solution:
    def longestConsecutive(self, nums):

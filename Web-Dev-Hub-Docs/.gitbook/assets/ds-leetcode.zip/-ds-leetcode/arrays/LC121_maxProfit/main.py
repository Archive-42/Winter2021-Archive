class Solution:
    def maxProfit(self, prices):

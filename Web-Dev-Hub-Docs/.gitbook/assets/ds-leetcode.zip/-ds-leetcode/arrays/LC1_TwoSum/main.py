class Solution:
    def twoSum(self, nums, target):

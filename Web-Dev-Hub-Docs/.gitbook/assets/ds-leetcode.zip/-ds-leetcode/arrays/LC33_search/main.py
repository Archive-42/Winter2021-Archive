class Solution:
    def search(self, nums, target):

class Solution:
    def reorderList(self, head):

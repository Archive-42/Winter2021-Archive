class Solution:
    def backspaceCompare(self, S, T):

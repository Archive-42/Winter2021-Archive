class Solution:
    def middleNode(self, head):

class Solution:
    def canJump(self, nums):

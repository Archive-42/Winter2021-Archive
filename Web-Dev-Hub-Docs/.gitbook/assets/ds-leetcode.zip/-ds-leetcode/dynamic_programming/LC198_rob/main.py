class Solution:
    def rob(self, nums):

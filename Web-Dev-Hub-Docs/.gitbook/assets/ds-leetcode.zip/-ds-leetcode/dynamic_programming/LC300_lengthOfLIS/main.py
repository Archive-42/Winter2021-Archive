class Solution:
    def lengthOfLIS(self, nums):

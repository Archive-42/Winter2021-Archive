class Solution:
    def invertTree(self, root):

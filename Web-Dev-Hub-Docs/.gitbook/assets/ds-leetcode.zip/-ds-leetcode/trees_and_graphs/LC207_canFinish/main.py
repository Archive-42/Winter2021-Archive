class Solution:
    def canFinish(self, N, edges):

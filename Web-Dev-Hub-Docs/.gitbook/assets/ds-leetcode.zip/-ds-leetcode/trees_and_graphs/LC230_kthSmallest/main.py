class Solution:
    def kthSmallest(self, root, k):

class WordDictionary:

    def __init__(self):

    def addWord(self, word):

    def search(self, word):

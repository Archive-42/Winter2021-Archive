class Solution:
    def isValidBST(self, root):

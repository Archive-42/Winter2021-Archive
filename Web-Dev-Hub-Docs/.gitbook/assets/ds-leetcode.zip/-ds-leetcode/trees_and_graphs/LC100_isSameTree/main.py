class Solution:
    def isSameTree(self, p, q):
